'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"canvaskit/chromium/canvaskit.js": "5e27aae346eee469027c80af0751d53d",
"canvaskit/chromium/canvaskit.js.symbols": "193deaca1a1424049326d4a91ad1d88d",
"canvaskit/chromium/canvaskit.wasm": "24c77e750a7fa6d474198905249ff506",
"canvaskit/canvaskit.js": "140ccb7d34d0a55065fbd422b843add6",
"canvaskit/canvaskit.js.symbols": "58832fbed59e00d2190aa295c4d70360",
"canvaskit/canvaskit.wasm": "07b9f5853202304d3b0749d9306573cc",
"canvaskit/skwasm.js": "1ef3ea3a0fec4569e5d531da25f34095",
"canvaskit/skwasm.js.symbols": "0088242d10d7e7d6d2649d1fe1bda7c1",
"canvaskit/skwasm.wasm": "264db41426307cfc7fa44b95a7772109",
"canvaskit/skwasm_heavy.js": "413f5b2b2d9345f37de148e2544f584f",
"canvaskit/skwasm_heavy.js.symbols": "3c01ec03b5de6d62c34e17014d1decd3",
"canvaskit/skwasm_heavy.wasm": "8034ad26ba2485dab2fd49bdd786837b",
"flutter.js": "888483df48293866f9f41d3d9274a779",
"flutter_bootstrap.js": "b6ad8a975a0add6b224f39030d9a1b5e",
"index.html": "1f77861b00a0d818c447e75872a7aa5c",
"/": "1f77861b00a0d818c447e75872a7aa5c",
"main.dart.js": "c32b070dc855249eabe83140946978fb",
"version.json": "d2634df75223f98291f7e9065e4c48e2",
"assets/assets/images/logo_huddl.png": "213e82f8274d6e9685c222204da18d15",
"assets/assets/images/logo_huddl_hq.png": "8d99a62c3a6aa6e8295a7e9318da6979",
"assets/assets/images/logo_huddl_icon.png": "257ab24cae3dd7e2c7a63256738da920",
"assets/assets/images/logo_huddl_splash.png": "a001980a3ed2931caed9e620f305d0ca",
"assets/assets/images/illustrations/Group_3603.png": "1e4cf45342e027cfd19b6f0a48c383ac",
"assets/assets/images/illustrations/man__woman__female__male__person__shapes__shape__layout-1.png": "b8e49373d19fd4866b3ecdc429f198da",
"assets/assets/images/illustrations/man__woman__female__male__person__shapes__shape__layout.png": "d37cc937638d2345b87b915a68ff0565",
"assets/assets/images/illustrations/not_available_illustration.png": "1ce2ed55998bb73b5a60a559aec0ea53",
"assets/assets/images/illustrations/onboarding_two_people_illustration.png": "8fca5675d52073046831cf5353b5eb81",
"assets/assets/images/illustrations/onboarding_welcome_illustration.png": "0b806917f21905e446df205db6f19bd0",
"assets/assets/images/illustrations/onboarding_chat_illustration.png": "bb314d02eaf8e2b4662dac8188225ac6",
"assets/assets/images/avatars/Emma.png": "c7cc6e7674a7b46085ff3d79a07f2cb4",
"assets/assets/images/avatars/John.png": "bbcf36163bc253206aeb3a932bfaf77a",
"assets/assets/images/avatars/Ruby.png": "77ab17d77320b09c8427fc2987441b17",
"assets/assets/images/avatars/avatar1.png": "c7cc6e7674a7b46085ff3d79a07f2cb4",
"assets/assets/images/avatars/avatar2.png": "bbcf36163bc253206aeb3a932bfaf77a",
"assets/assets/images/avatars/avatar3.png": "77ab17d77320b09c8427fc2987441b17",
"assets/assets/images/avatars/avatar4.png": "c7cc6e7674a7b46085ff3d79a07f2cb4",
"assets/assets/images/avatars/avatar5.png": "bbcf36163bc253206aeb3a932bfaf77a",
"assets/assets/images/groups/cambridge_kings_college.jpg": "e7a31edecf35cf0a928f1df53e9ff1f9",
"assets/assets/images/groups/cambridge_punting.jpg": "214d9939387777498cd997f21ca62a4c",
"assets/assets/images/groups/cambridge_river_boats.jpg": "9a64b2d77255340c490be4668e80b915",
"assets/assets/images/groups/cambridge_the_backs.jpg": "3472a20ed30a38c01b2975d74c57581a",
"assets/assets/images/groups/cambridge_trinity.jpg": "66c5ff8390ddc0408906ad0f912bf224",
"assets/assets/images/groups/east_cambs_ely_cathedral.jpg": "dd9f5dcbf561063a8872ca2ef8b42f07",
"assets/assets/images/groups/south_cambs_village.jpg": "b4cb3a8026c961dcadd1440037797ef8",
"assets/assets/icons/app_icon.png": "1c489dae3ef60b9020f033a13522f009",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/fonts/MaterialIcons-Regular.otf": "c752a22bb3abc8ceecdd7f3af5d4b026",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.json": "74678e69861da15be93f7436f33f7303",
"assets/AssetManifest.bin": "0ecb98ee046e0cf090fc13eea1920d09",
"assets/AssetManifest.bin.json": "15560322636d4f4327e029c843b0f74e",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/NOTICES": "e84cb3e244c52cbcdffb103f0fc59173",
"favicon.png": "bc54fda0acf37a86657cc012b816f15c",
"icons/Icon-192.png": "cbf011ce3134c6b2c0ee912ea402a85d",
"icons/Icon-512.png": "b381a5d78830de101d2c5954bfe2b927",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"manifest.json": "d14fdd96b3758b21903590aba996c0a4"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
