import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../../services/onboarding_data_service.dart';
import '../legal/terms_of_service_screen.dart';
import '../legal/privacy_policy_detail_screen.dart';
import '../../theme/huddl_colors.dart';
import '../../widgets/onboarding_progress_bar.dart';


// ── Password strength helpers ─────────────────────────────────────────────────

enum _Strength { empty, weak, fair, good, strong }

class _PasswordPolicy {
  static bool hasMinLength(String p) => p.length >= 8;
  static bool hasUppercase(String p) => p.contains(RegExp(r'[A-Z]'));
  static bool hasLowercase(String p) => p.contains(RegExp(r'[a-z]'));
  static bool hasDigit(String p) => p.contains(RegExp(r'[0-9]'));
  static bool hasSpecial(String p) =>
      p.contains(RegExp(r'[!@#$%^&*()+\-=\[\]{};:.,<>?/|`~@_]'));

  static bool isValid(String p) =>
      hasMinLength(p) &&
      hasUppercase(p) &&
      hasLowercase(p) &&
      hasDigit(p) &&
      hasSpecial(p);

  static _Strength strength(String p) {
    if (p.isEmpty) return _Strength.empty;
    int score = 0;
    if (hasMinLength(p)) score++;
    if (hasUppercase(p)) score++;
    if (hasLowercase(p)) score++;
    if (hasDigit(p)) score++;
    if (hasSpecial(p)) score++;
    if (score <= 1) return _Strength.weak;
    if (score == 2) return _Strength.fair;
    if (score == 3 || score == 4) return _Strength.good;
    return _Strength.strong;
  }
}

// ── Screen ────────────────────────────────────────────────────────────────────

class PasswordScreen extends StatefulWidget {
  const PasswordScreen({super.key});

  @override
  State<PasswordScreen> createState() => _PasswordScreenState();
}

class _PasswordScreenState extends State<PasswordScreen> {
  final _passCtrl = TextEditingController();
  final _repeatCtrl = TextEditingController();
  bool _obscurePass = true;
  bool _obscureRepeat = true;
  String? _errorMsg;
  bool _isLoading = false;
  bool _agreedToTerms = false;

  @override
  void initState() {
    super.initState();
    _passCtrl.addListener(_onChanged);
    _repeatCtrl.addListener(_onChanged);
  }

  @override
  void dispose() {
    _passCtrl.dispose();
    _repeatCtrl.dispose();
    super.dispose();
  }

  void _onChanged() => setState(() {
        _errorMsg = null;
        if (_repeatCtrl.text.isNotEmpty &&
            _passCtrl.text != _repeatCtrl.text) {
          _errorMsg = 'Passwords do not match';
        }
      });

  bool get _canCreate =>
      _PasswordPolicy.isValid(_passCtrl.text) &&
      _passCtrl.text == _repeatCtrl.text &&
      _repeatCtrl.text.isNotEmpty &&
      _agreedToTerms;

  Future<void> _createAccount() async {
    if (!_canCreate) return;
    setState(() {
      _isLoading = true;
      _errorMsg = null;
    });

    final onboardingService = OnboardingDataService();
    onboardingService.setPassword(_passCtrl.text);

    // On web, Firebase phone auth (reCAPTCHA) cannot work in sandboxed
    // environments. Skip the verification screen entirely — save data
    // locally and proceed straight to welcome. The real phone-OTP
    // verification happens on the native Android app.
    if (kIsWeb) {
      onboardingService.setPhoneVerified(true);
      setState(() => _isLoading = false);
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
            context, '/welcome_complete', (route) => false);
      }
      return;
    }

    // On mobile, go through the normal phone OTP verification flow
    setState(() => _isLoading = false);
    if (mounted) Navigator.pushNamed(context, '/verification');
  }

  @override
  Widget build(BuildContext context) {
    final pw = _passCtrl.text;
    final strength = _PasswordPolicy.strength(pw);

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            _OnboardingAppBar(onBack: () => Navigator.pop(context)),
            OnboardingProgressBar(step: OnboardingStep.password),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 36),

                    // Title
                    Text(
                      'Create a password',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Choose a strong password to keep your account secure.',
                      style: TextStyle(
                          fontSize: 14, color: HuddlColors.disabledText, height: 1.5),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 32),

                    // Password field
                    _PasswordInput(
                      controller: _passCtrl,
                      hint: 'Enter your password',
                      obscure: _obscurePass,
                      onToggle: () =>
                          setState(() => _obscurePass = !_obscurePass),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 10),

                    // Strength bar
                    if (pw.isNotEmpty) ...[
                      _StrengthBar(strength: strength),
                      const SizedBox(height: 10),
                    ],

                    // Requirements checklist
                    _RequirementsPanel(password: pw),
                    const SizedBox(height: 20),

                    // Confirm password field
                    _PasswordInput(
                      controller: _repeatCtrl,
                      hint: 'Confirm your password',
                      obscure: _obscureRepeat,
                      onToggle: () =>
                          setState(() => _obscureRepeat = !_obscureRepeat),
                      onChanged: (_) => setState(() {}),
                    ),

                    // Error message
                    if (_errorMsg != null) ...[
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          _errorMsg!,
                          style: const TextStyle(
                              fontSize: 13,
                              color: HuddlColors.error,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],

                    const SizedBox(height: 24),

                    // GDPR consent checkbox
                    GestureDetector(
                      onTap: () => setState(() => _agreedToTerms = !_agreedToTerms),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 24,
                            height: 24,
                            child: Checkbox(
                              value: _agreedToTerms,
                              onChanged: (v) => setState(() => _agreedToTerms = v ?? false),
                              activeColor: HuddlColors.onboardingOrange,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: RichText(
                              text: TextSpan(
                                style: const TextStyle(
                                    fontSize: 13, color: HuddlColors.disabledText, height: 1.5),
                                children: [
                                  const TextSpan(
                                      text: "I agree to Huddl's "),
                                  TextSpan(
                                    text: 'Terms of Service',
                                    style: const TextStyle(
                                      color: HuddlColors.onboardingOrange,
                                      fontWeight: FontWeight.w600,
                                      decoration: TextDecoration.underline,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) =>
                                                const TermsOfServiceScreen(),
                                          ),
                                        );
                                      },
                                  ),
                                  const TextSpan(text: ' and '),
                                  TextSpan(
                                    text: 'Privacy Policy',
                                    style: const TextStyle(
                                      color: HuddlColors.onboardingOrange,
                                      fontWeight: FontWeight.w600,
                                      decoration: TextDecoration.underline,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) =>
                                                const PrivacyPolicyDetailScreen(),
                                          ),
                                        );
                                      },
                                  ),
                                  const TextSpan(
                                      text: ', including the processing of my personal data as described in the Privacy Policy.'),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Create account button
                    _OrangeButton(
                      label: _isLoading ? 'Creating...' : 'Create account',
                      enabled: _canCreate && !_isLoading,
                      onTap: _createAccount,
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Strength bar ──────────────────────────────────────────────────────────────

class _StrengthBar extends StatelessWidget {
  final _Strength strength;
  const _StrengthBar({required this.strength});

  @override
  Widget build(BuildContext context) {
    final data = _strengthData(strength);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: List.generate(4, (i) {
            final filled = i < data.segments;
            return Expanded(
              child: Container(
                margin: EdgeInsets.only(right: i < 3 ? 4 : 0),
                height: 4,
                decoration: BoxDecoration(
                  color: filled ? data.color : HuddlColors.inputBorderLight,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 4),
        Text(
          data.label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: data.color,
          ),
        ),
      ],
    );
  }

  ({int segments, Color color, String label}) _strengthData(_Strength s) {
    switch (s) {
      case _Strength.weak:
        return (segments: 1, color: HuddlColors.error, label: 'Weak');
      case _Strength.fair:
        return (segments: 2, color: HuddlColors.warning, label: 'Fair');
      case _Strength.good:
        return (segments: 3, color: HuddlColors.teal, label: 'Good');
      case _Strength.strong:
        return (segments: 4, color: HuddlColors.success, label: 'Strong');
      case _Strength.empty:
        return (segments: 0, color: HuddlColors.inputBorderLight, label: '');
    }
  }
}

// ── Requirements checklist ────────────────────────────────────────────────────

class _RequirementsPanel extends StatelessWidget {
  final String password;
  const _RequirementsPanel({required this.password});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: HuddlColors.surfaceLight,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: HuddlColors.disabled),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Password must contain:',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          _Req('At least 8 characters',
              _PasswordPolicy.hasMinLength(password)),
          _Req('At least one uppercase letter (A–Z)',
              _PasswordPolicy.hasUppercase(password)),
          _Req('At least one lowercase letter (a–z)',
              _PasswordPolicy.hasLowercase(password)),
          _Req('At least one number (0–9)',
              _PasswordPolicy.hasDigit(password)),
          _Req('At least one special character (!@#\$%^&*…)',
              _PasswordPolicy.hasSpecial(password)),
        ],
      ),
    );
  }
}

class _Req extends StatelessWidget {
  final String label;
  final bool met;
  const _Req(this.label, this.met);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Row(
        children: [
          Icon(
            met ? Icons.check_circle_rounded : Icons.radio_button_unchecked,
            size: 14,
            color: met ? HuddlColors.success : HuddlColors.disabledText,
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: met ? Theme.of(context).colorScheme.onSurface : HuddlColors.disabledText,
                fontWeight: met ? FontWeight.w500 : FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Password input field ──────────────────────────────────────────────────────

class _PasswordInput extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final bool obscure;
  final VoidCallback onToggle;
  final ValueChanged<String>? onChanged;

  const _PasswordInput({
    required this.controller,
    required this.hint,
    required this.obscure,
    required this.onToggle,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).inputDecorationTheme.fillColor ?? context.hc.inputBg,
        border: Border(bottom: BorderSide(color: Theme.of(context).dividerColor, width: 1.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16, top: 8),
            child: Text(
              hint,
              style: TextStyle(fontSize: 11, color: HuddlColors.disabledText),
            ),
          ),
          TextField(
            controller: controller,
            obscureText: obscure,
            onChanged: onChanged,
            style: TextStyle(fontSize: 16, color: Theme.of(context).colorScheme.onSurface),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.fromLTRB(16, 2, 16, 12),
              suffixIcon: IconButton(
                icon: Icon(
                  obscure
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: HuddlColors.disabledText,
                  size: 22,
                ),
                onPressed: onToggle,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Shared widgets ────────────────────────────────────────────────────────────

class _OnboardingAppBar extends StatelessWidget {
  final VoidCallback onBack;
  const _OnboardingAppBar({required this.onBack});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
      child: Row(children: [
        IconButton(
            icon: const Icon(Icons.chevron_left, size: 30, color: HuddlColors.onboardingOrange),
            onPressed: onBack,
            padding: EdgeInsets.zero),
        const Expanded(child: _HuddlLogo()),
        const SizedBox(width: 48),
      ]),
    );
  }
}

class _HuddlLogo extends StatelessWidget {
  const _HuddlLogo();

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/images/logo_huddl_splash.png',
      height: 34,
      fit: BoxFit.contain,
    );
  }
}

class _OrangeButton extends StatelessWidget {
  final String label;
  final bool enabled;
  final VoidCallback onTap;
  const _OrangeButton(
      {required this.label, required this.enabled, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Container(
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
            color: enabled ? HuddlColors.onboardingOrange : HuddlColors.disabled,
            borderRadius: BorderRadius.circular(12)),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: enabled ? Colors.white : HuddlColors.disabledText),
        ),
      ),
    );
  }
}
