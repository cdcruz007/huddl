HUDDL APP — SCREEN FILES EXPORT
================================
Generated: 22 May 2026
Build:     v1.1.21+59 (commit 597824b)
Total screens: 63 Dart files

DIRECTORY STRUCTURE
-------------------
screens/
  admin/          — Admin dashboard
  ai/             — Huddl Co-pilot / AI assistant
  auth/           — Login, OTP, biometric lock
  debug/          — Borough debug (internal)
  events/         — Events & Meetups (list, detail, create, edit)
  groups/         — Connect tab: groups, chat, DMs, polls, threads
  home/           — Home feed + journey map
  insights/       — Insights: articles, experts, community wisdom
  legal/          — Privacy policy, terms of service
  marketplace/    — Market: buy/sell/saved, item detail
  offers/         — Offers management
  onboarding/     — Full onboarding flow (14 screens)
  profile/        — Profile, settings, backup/restore
  rehome/         — Create listing
  services/       — Local Services tab
  subscription/   — Subscription plans, checkout, manage
  main_shell.dart — Bottom nav shell / tab controller

theme/
  huddl_colors.dart    — Brand colour palette
  huddl_theme.dart     — Light + dark theme data
  huddl_animations.dart — Haptics, ScaleOnPress, celebration overlay

